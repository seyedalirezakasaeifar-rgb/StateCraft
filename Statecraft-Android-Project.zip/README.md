# STATECRAFT

A deep political simulation for Android, in the spirit of *Democracy 4* — run a country quarter by quarter,
balance a web of ~400 interlinked systems, and keep 2,400 simulated voters on side until the next election.

* **172 policies** across 16 departments (taxes, central bank, welfare, health, education, law & order, immigration,
  defence, foreign affairs, transport, housing, environment & energy, society, democracy & media …)
* **127 statistics + 6 derived budget variables**, **61 situations**, **37 voter groups**, **77 dilemmas** + dynamic
  protests / scandals / leadership challenges, **41 achievements**, **15 playable countries**, **8 foreign nations**
* ~**2,200 weighted links** between everything. Open the **Board** and tap any node to see what it affects and what affects it.

Beyond Democracy 4: individual-voter electorate whose ideology drifts with your laws, regional map and real seat
allocation (winner-takes-all / mixed / proportional / electoral college / runoff), legislature that can vote your bills
down, coalition pledges, ministers with traits and scandals, six media outlets with their own slant, treaties,
sanctions and war, campaign mechanics, voters that adapt to the new normal, protest movements, coups, revolutions,
bankruptcy, a legacy score, save slots + autosave, JSON modding, colour-blind mode.

## Build the APK

### Option A — Android Studio (easiest)
1. Install Android Studio (Hedgehog or newer).
2. **File ▸ Open** and choose this folder. Let Gradle sync (it downloads Gradle 8.5 and the Android Gradle Plugin).
3. **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**. The APK is in `app/build/outputs/apk/debug/app-debug.apk`.
4. Copy it to your phone and install it (allow "install unknown apps"), or press ▶ with the phone plugged in.

### Option B — command line
Requires JDK 17, the Android SDK (`ANDROID_HOME` set) and Gradle 8.5:
```
gradle assembleDebug
```

### Option C — GitHub Actions (no local setup)
Push this folder to a GitHub repository. `.github/workflows/build-apk.yml` builds the APK on every push; download
it from the workflow run's **Artifacts**.

`minSdk 26` (Android 8.0+). No third-party libraries — only the Android Gradle Plugin.

## Play in a browser
`python3 tools/build_single.py` writes `dist/statecraft.html`, a single self-contained file.

## Project layout
```
app/src/main/java/…/MainActivity.java   native shell (WebView, back button, haptics)
app/src/main/assets/www/                the entire game
  js/data/   stats, policies, voter groups, situations, events, countries, achievements
  js/core/   graph, voters, economy, politics, events, world, sim, save
  js/ui/     board, detail sheets, screens, turn flow
tools/       headless tests (node) and the single-file bundler
```

## Modding
Open **Mods** in the app and paste JSON. Keys: `stats`, `policies`, `groups`, `situations`, `events`, `countries`,
`achievements`. Effects use the same compact syntax as the built-in data — `"target:weight[curve]"` — e.g.
`"crime:-.30 civil_rights:-.05"`. Or edit the files in `assets/www/js/data/` directly and rebuild.

## Tests
```
node tools/check_data.js      # validates every link, icon and rule
node tools/check_events.js    # validates events & achievements
node tools/sim_test.js uk 48 random   # headless simulation (countries: usa uk france … ; modes: idle random extreme austerity)
```
