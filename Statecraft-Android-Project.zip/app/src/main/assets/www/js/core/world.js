/* STATECRAFT — world engine: diplomacy, treaties, war, media */

SC.initWorld = function (G) {
  G.world = { nations: {} };
  for (const n of SC.D.nations) G.world.nations[n.id] = { rel: n.rel0 + Math.round((G.rng() - .5) * 8), tens: n.hostile * .5, treaties: [], sanctions: false, cd: {} };
  G.war = null; G.treatyAdd = {};
};

SC.natById = id => SC.D.nations.find(n => n.id === id);

SC.worldTurn = function (G) {
  const W = G.world, add = {};
  let sumRel = 0, maxT = 0;
  for (const nat of SC.D.nations) {
    const st = W.nations[nat.id];
    const base = 50 + 38 * (SC.closeness(G.pIdeo[0], nat.ideo) - .5) - nat.hostile * 32 + (G.x.foreign_relations - .5) * 28 + st.treaties.length * 7 - (st.sanctions ? 25 : 0) + (G.x.international_standing - .5) * 10;
    st.rel = SC.clamp(st.rel + (base - st.rel) * .07 + SC.gauss(G.rng) * 1.6, -100, 100);
    st.tens = SC.clamp(nat.hostile * .45 + (50 - st.rel) / 140 + G.x.global_tension * .35 - st.treaties.length * .05, 0, 1);
    for (const k in st.cd) { st.cd[k]--; if (st.cd[k] <= 0) delete st.cd[k]; }
    sumRel += st.rel; if (st.tens > maxT) maxT = st.tens;
    /* treaty effects */
    for (const tid of st.treaties) {
      const t = SC.D.treaties.find(x => x.id === tid); if (!t) continue;
      for (const f of SC.parseFx(t.fx)) add[f.t] = (add[f.t] || 0) + f.w * nat.gdp * (1 + (st.rel - 50) / 200);
    }
    if (st.sanctions) { add.exports = (add.exports || 0) - .012 * nat.gdp; }
    /* treaty lapse when relations collapse */
    if (st.rel < 5 && st.treaties.length && G.rng() < .2) { const lost = st.treaties.pop(); G.newsQueue.push('Diplomatic rupture: the ' + lost + ' arrangement with ' + nat.n + ' collapses.'); }
  }
  const avg = sumRel / SC.D.nations.length;
  add.foreign_relations = (add.foreign_relations || 0) + (avg - 50) / 500;
  add.foreign_threat = (add.foreign_threat || 0) + Math.max(0, maxT - .35) * .09;
  G.treatyAdd = add;
  G.worldAvgRel = avg; G.worldMaxTens = maxT;
  SC.warTurn(G);
};

SC.canAct = function (G, action, natId) {
  const st = G.world.nations[natId];
  if (st.cd[action.id]) return { ok: false, why: 'Available again in ' + st.cd[action.id] + ' turns' };
  if (action.minRel && st.rel < action.minRel) return { ok: false, why: 'Needs relations of ' + action.minRel + '+' };
  if (!G.o.sandbox && G.pc < action.pc) return { ok: false, why: 'Needs ' + action.pc + ' political capital' };
  return { ok: true };
};
SC.doAction = function (G, actionId, natId) {
  const a = SC.D.actions.find(x => x.id === actionId), st = G.world.nations[natId], nat = SC.natById(natId);
  const chk = SC.canAct(G, a, natId); if (!chk.ok) return chk;
  if (!G.o.sandbox) G.pc -= a.pc;
  st.rel = SC.clamp(st.rel + a.rel, -100, 100); st.cd[a.id] = a.cd;
  if (a.id === 'sanction') st.sanctions = true;
  if (a.e) { const e = Object.assign({}, a.e); if (e.tens) { st.tens = SC.clamp(st.tens + e.tens, 0, 1); delete e.tens; } SC.applyEffect(G, e); }
  if (a.id === 'summit' && st.sanctions && st.rel > 40) st.sanctions = false;
  return { ok: true, msg: a.n + ' with ' + nat.n + ': relations ' + (a.rel > 0 ? 'improve' : 'worsen') + '.' };
};
SC.liftSanctions = function (G, natId) { const st = G.world.nations[natId]; if (!st.sanctions) return; st.sanctions = false; st.rel = Math.min(100, st.rel + 8); };
SC.signTreaty = function (G, treatyId, natId) {
  const t = SC.D.treaties.find(x => x.id === treatyId), st = G.world.nations[natId], nat = SC.natById(natId);
  if (st.treaties.indexOf(treatyId) >= 0) return { ok: false, why: 'Already in force' };
  if (st.rel < t.minRel) return { ok: false, why: 'Needs relations of ' + t.minRel + '+' };
  if (!G.o.sandbox && G.pc < t.pc) return { ok: false, why: 'Needs ' + t.pc + ' political capital' };
  if (!G.o.sandbox) G.pc -= t.pc;
  st.treaties.push(treatyId); st.rel = Math.min(100, st.rel + 5);
  G.newsQueue.push('Signed: ' + t.n + ' with ' + nat.n + '.');
  return { ok: true, msg: t.n + ' signed with ' + nat.n + '.' };
};
SC.cancelTreaty = function (G, treatyId, natId) {
  const st = G.world.nations[natId]; const i = st.treaties.indexOf(treatyId); if (i < 0) return;
  st.treaties.splice(i, 1); st.rel = Math.max(-100, st.rel - 12);
};

/* ---------- war ---------- */
SC.startWar = function (G, natId) {
  if (G.war) return;
  const nat = SC.natById(natId);
  G.war = { nation: natId, turns: 0, dur: 3 + Math.floor(G.rng() * 4), momentum: 0 };
  G.world.nations[natId].rel = Math.min(G.world.nations[natId].rel, -80);
  G.newsQueue.push('WAR: ' + nat.n + ' and ' + G.C.name + ' are at war.');
};
SC.warTurn = function (G) {
  const w = G.war; if (!w) return;
  w.turns++; G.sitForce.at_war = 2;
  const nat = SC.natById(w.nation);
  const allies = Object.values(G.world.nations).reduce((s, n) => s + (n.treaties.indexOf('defence') >= 0 ? 1 : 0), 0);
  const power = .5 * G.x.military_strength + .15 * G.x.national_security + .1 * G.x.intelligence + .07 * allies + .08 * G.x.cyber_defence - nat.str * .55 + .18;
  w.momentum += (power - .35) * .5 + SC.gauss(G.rng) * .1;
  SC.addMod(G, 'gdp_growth', -.015, 2);
  G.moodMod.young = (G.moodMod.young || 0) - .01;
  G.moodMod.veterans = (G.moodMod.veterans || 0) + .01;
  G.eco.debt += .006 * G.eco.gdp;
  if (w.turns >= w.dur) {
    const win = w.momentum > 0;
    G.war = null; delete G.sitForce.at_war;
    G.warResult = { won: win, nation: w.nation, turn: G.turn };
    if (win) {
      SC.applyEffect(G, { s: { national_pride: .08, leader_approval: .07, international_standing: .03, foreign_threat: -.06 }, m: { nationalists: .1, veterans: .1, authoritarians: .05 }, news: 'VICTORY: ' + G.C.name + ' prevails over ' + nat.n + '.' });
      G.world.nations[w.nation].rel = -40;
    } else {
      SC.applyEffect(G, { s: { national_pride: -.08, leader_approval: -.08, international_standing: -.04, foreign_threat: .05, gdp_growth: -.02 }, m: { nationalists: -.12, veterans: -.08 }, news: 'DEFEAT: ' + G.C.name + ' agrees a humiliating ceasefire with ' + nat.n + '.' });
    }
  }
};

/* ---------- media ---------- */
SC.initMedia = function (G) {
  const vt = G.vt, outs = SC.D.outlets;
  const r = SC.mkRng((G.seed ^ 0x51ed27) | 0);
  const tot = outs.reduce((s, o) => s + o.reach, 0);
  for (let i = 0; i < vt.n; i++) {
    if (r() > .82) { vt.aud[i] = -1; continue; }
    let best = -1, bv = -9;
    for (let k = 0; k < outs.length; k++) {
      const o = outs[k]; let v = o.reach * 2.5 + (o.state ? .05 : SC.closeness([vt.ido[i * 5], vt.ido[i * 5 + 1], vt.ido[i * 5 + 2], vt.ido[i * 5 + 3], vt.ido[i * 5 + 4]], o.ideo)) * 1.2 + r() * .45;
      if (v > bv) { bv = v; best = k; }
    }
    vt.aud[i] = best;
  }
  G.mediaTone = outs.map(() => 0);
};
SC.mediaTurn = function (G, sentiment) {
  const outs = SC.D.outlets;
  G.mediaTone = outs.map((o, i) => {
    let a;
    if (o.state) a = (G.x.media_tone - .5) * 2.0;
    else a = (SC.closeness(G.pIdeo[0], o.ideo) - .5) * 1.7 + sentiment * .5 + (G.x.media_tone - .5) * .9;
    a = SC.clamp(a * (o.state ? 1 : (0.7 + .3 * o.cred)), -1, 1);
    return (G.mediaTone[i] || 0) * .5 + a * .5;
  });
  let sum = 0, rs = 0; outs.forEach((o, i) => { sum += o.reach * G.mediaTone[i]; rs += o.reach; });
  G.mediaAvg = sum / rs;
};

/* Build headlines from what happened this turn. stories: [{kind, name, good, val, dir, w}] */
SC.headline = function (G, o, tone, s) {
  const p = tone > .25 ? 'f' : tone < -.25 ? 'h' : 'n', pick = arr => SC.pick(G.rng, arr);
  const nm = s.name, v = s.val;
  switch (s.kind) {
    case 'policy': {
      const verb = s.dir > 0 ? 'raises' : 'cuts';
      if (p === 'f') return pick(['Bold move: government ' + verb + ' ' + nm, 'Ministers ' + verb + ' ' + nm + ' in decisive step', 'Government ' + verb + ' ' + nm + ' as promised']);
      if (p === 'h') return pick(['Anger as ministers ' + verb + ' ' + nm, nm + ' shake-up ' + (s.dir > 0 ? 'hits families' : 'raises alarm'), 'Critics round on government over ' + nm + ' change']);
      return pick(['Government ' + verb + ' ' + nm, nm + ' ' + (s.dir > 0 ? 'increased' : 'reduced') + ' in latest package']);
    }
    case 'stat':
      if (s.good) {
        if (p === 'f') return pick([nm + ' improves to ' + v + ': government success', 'Progress on ' + nm.toLowerCase() + ' — figures hailed as vindication']);
        if (p === 'h') return pick(['Experts doubt ' + nm.toLowerCase() + ' gains will last', 'Ministers claim credit as ' + nm.toLowerCase() + ' edges up']);
        return pick([nm + ' improves to ' + v, nm + ' up in latest figures']);
      } else {
        if (p === 'f') return pick([nm + ' dips, but ministers vow action', 'Setback on ' + nm.toLowerCase() + ' blamed on global conditions']);
        if (p === 'h') return pick(['Crisis deepens as ' + nm.toLowerCase() + ' slides to ' + v, nm + ' slump piles pressure on ' + 'the government']);
        return pick([nm + ' worsens to ' + v, nm + ' falls in latest figures']);
      }
    case 'sit':
      if (s.start) {
        if (s.good) return p === 'h' ? pick(['Government touts ' + nm.toLowerCase() + ' while others struggle']) : pick([nm + ' arrives', 'Good news: ' + nm.toLowerCase() + ' takes hold']);
        if (p === 'f') return pick(['Government responds to ' + nm.toLowerCase()]);
        if (p === 'h') return pick(['Ministers blamed as ' + nm.toLowerCase() + ' grips nation', nm + ': who is in charge?']);
        return pick([nm + ' takes hold across ' + G.C.name, 'Warning signs as ' + nm.toLowerCase() + ' emerges']);
      } else return p === 'h' ? pick(['Relief, but ' + nm.toLowerCase() + ' scars will remain']) : pick([nm + ' finally ends', 'End of ' + nm.toLowerCase() + ' welcomed']);
    case 'poll': {
      const d = s.dir;
      if (p === 'f') return d >= 0 ? pick(['Poll boost for ' + G.parties[0].n + ' — ' + v]) : pick(['Poll wobble is just noise, say allies (' + v + ')']);
      if (p === 'h') return d >= 0 ? pick(['Poll bounce is fragile, warn analysts (' + v + ')']) : pick(['Poll slump for ' + G.parties[0].n + ': ' + v, 'Voters turning away: ' + v]);
      return pick(['Latest poll: ' + G.parties[0].n + ' on ' + v, 'Opinion poll puts ' + G.parties[0].n + ' at ' + v]);
    }
    case 'text': return s.name;
  }
  return nm;
};
SC.makeNews = function (G, stories) {
  const outs = SC.D.outlets, news = [];
  const ss = stories.slice().sort((a, b) => b.w - a.w);
  const queued = G.newsQueue.splice(0);
  outs.forEach((o, i) => {
    const tone = G.mediaTone[i] || 0;
    let s = null;
    if (queued.length && (i === 0 || G.rng() < .4)) s = { kind: 'text', name: queued[i % queued.length], w: 1 };
    else if (ss.length) {
      /* hostile outlets prefer bad news, friendly prefer good */
      const scored = ss.map(t => ({ t, sc: t.w * (1 + (tone > .25 ? (t.good ? .6 : -.4) : tone < -.25 ? (t.good ? -.4 : .6) : 0)) + G.rng() * .3 }));
      scored.sort((a, b) => b.sc - a.sc); s = scored[Math.min(scored.length - 1, Math.floor(G.rng() * Math.min(3, scored.length)))].t;
    }
    if (s) news.push({ outlet: o.id, text: SC.headline(G, o, tone, s), tone: tone > .25 ? 'pro' : tone < -.25 ? 'anti' : 'neutral' });
  });
  return news;
};
