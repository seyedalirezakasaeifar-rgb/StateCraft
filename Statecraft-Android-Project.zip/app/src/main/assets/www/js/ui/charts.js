/* STATECRAFT — charts, maps, portraits (SVG string builders) */
(function () {
  const h = SC.h, UI = SC.UI;
  const wrap = (html, style) => h('div', { html, style: style || {} });

  UI.spark = function (vals, w, ht, color, o) {
    o = o || {}; w = w || 120; ht = ht || 34;
    if (!vals || vals.length < 2) return wrap('<svg width="' + w + '" height="' + ht + '"></svg>');
    const mn = o.min != null ? o.min : Math.min.apply(null, vals), mx = o.max != null ? o.max : Math.max.apply(null, vals), rg = (mx - mn) || 1;
    const pts = vals.map((v, i) => [2 + (w - 4) * i / (vals.length - 1), ht - 3 - (ht - 6) * (v - mn) / rg]);
    const line = pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
    const area = '2,' + (ht - 2) + ' ' + line + ' ' + (w - 2) + ',' + (ht - 2);
    const last = pts[pts.length - 1];
    return wrap(`<svg width="${w}" height="${ht}" viewBox="0 0 ${w} ${ht}"><polygon points="${area}" fill="${color}" opacity=".15"/><polyline points="${line}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/><circle cx="${last[0]}" cy="${last[1]}" r="3" fill="${color}"/></svg>`);
  };

  /* series: [{name,color,vals}]; xs: turn numbers; marks: [turn] */
  UI.lineChart = function (series, o) {
    o = o || {}; const W = o.w || 340, H = o.h || 170, pl = 34, pr = 8, pt = 8, pb = 20;
    let all = []; series.forEach(s => all = all.concat(s.vals));
    if (!all.length) return wrap('<div class="tip">No data yet.</div>');
    let mn = o.min != null ? o.min : Math.min.apply(null, all), mx = o.max != null ? o.max : Math.max.apply(null, all);
    if (mx - mn < 1e-6) { mx += .5; mn -= .5; } else { const pad = (mx - mn) * .08; if (o.min == null) mn -= pad; if (o.max == null) mx += pad; }
    const n = Math.max.apply(null, series.map(s => s.vals.length)), xs = o.xs || Array.from({ length: n }, (_, i) => i);
    const X = i => pl + (W - pl - pr) * (n > 1 ? i / (n - 1) : 0), Y = v => pt + (H - pt - pb) * (1 - (v - mn) / (mx - mn));
    const fmt = o.fmt || (v => Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 10 ? v.toFixed(1) : v.toFixed(2));
    let g = '';
    for (let k = 0; k <= 3; k++) { const v = mn + (mx - mn) * k / 3, y = Y(v); g += `<line x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}" stroke="#ffffff14"/><text x="${pl - 4}" y="${y + 3}" text-anchor="end">${fmt(v)}</text>`; }
    const step = Math.max(1, Math.ceil(n / 6));
    for (let i = 0; i < n; i += step) g += `<text x="${X(i)}" y="${H - 5}" text-anchor="middle">${o.xlab ? o.xlab(xs[i]) : xs[i]}</text>`;
    (o.marks || []).forEach(m => { const i = xs.indexOf(m); if (i >= 0) g += `<line x1="${X(i)}" x2="${X(i)}" y1="${pt}" y2="${H - pb}" stroke="#ffb84a" stroke-dasharray="3 3" opacity=".6"/>`; });
    if (o.ref != null) g += `<line x1="${pl}" x2="${W - pr}" y1="${Y(o.ref)}" y2="${Y(o.ref)}" stroke="#ff5d66" stroke-dasharray="4 3" opacity=".7"/>`;
    series.forEach(s => {
      const pts = s.vals.map((v, i) => X(i).toFixed(1) + ',' + Y(v).toFixed(1)).join(' ');
      g += `<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>`;
    });
    const legend = series.length > 1 ? '<div class="legend">' + series.map(s => `<span><i style="background:${s.color}"></i>${SC.esc(s.name)}</span>`).join('') + '</div>' : '';
    return wrap(`<svg class="chart" width="100%" viewBox="0 0 ${W} ${H}">${g}</svg>${legend}`);
  };

  UI.donut = function (items, size, center) {
    size = size || 170; const tot = items.reduce((s, i) => s + i.val, 0) || 1, r = size / 2 - 14, cx = size / 2, C = 2 * Math.PI * r;
    let off = 0, arcs = '';
    items.forEach(it => { const len = C * it.val / tot; arcs += `<circle cx="${cx}" cy="${cx}" r="${r}" fill="none" stroke="${it.color}" stroke-width="22" stroke-dasharray="${Math.max(0, len - 1.5)} ${C}" stroke-dashoffset="${-off}" transform="rotate(-90 ${cx} ${cx})"/>`; off += len; });
    return wrap(`<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${arcs}${center ? `<text x="${cx}" y="${cx - 2}" text-anchor="middle" style="font-size:18px;font-weight:700;fill:#e8eefb">${center[0]}</text><text x="${cx}" y="${cx + 14}" text-anchor="middle" style="font-size:10px">${center[1] || ''}</text>` : ''}</svg>`, { display: 'flex', justifyContent: 'center' });
  };

  UI.stackBar = function (items, total) {
    const tot = total || items.reduce((s, i) => s + i.v, 0) || 1;
    return h('div', { class: 'cmpbar' }, items.map(i => h('i', { style: { width: (i.v / tot * 100) + '%', background: i.c }, title: i.n })));
  };

  /* Parliament hemicycle. seats: array of counts, cols: colors, order: indices left->right */
  UI.hemicycle = function (seats, cols, order, W) {
    W = W || 340; const H = W * .56, total = seats.reduce((a, b) => a + b, 0) || 1;
    const rows = Math.max(3, Math.round(Math.sqrt(total) / 2.3)), cx = W / 2, cy = H - 6, R = W / 2 - 8, r0 = R * .38;
    const radii = Array.from({ length: rows }, (_, i) => r0 + (R - r0) * (rows > 1 ? i / (rows - 1) : 1));
    const sumR = radii.reduce((a, b) => a + b, 0); let counts = radii.map(r => Math.round(total * r / sumR)); let diff = total - counts.reduce((a, b) => a + b, 0);
    for (let i = rows - 1; diff !== 0; i = (i - 1 + rows) % rows) { counts[i] += diff > 0 ? 1 : -1; diff += diff > 0 ? -1 : 1; }
    const dots = []; radii.forEach((r, ri) => { for (let k = 0; k < counts[ri]; k++) dots.push({ a: Math.PI * (1 - (k + .5) / counts[ri]), r }); });
    dots.sort((p, q) => q.a - p.a || p.r - q.r);
    const dr = Math.min((R - r0) / Math.max(1, rows - 1) / 2.25, Math.PI * r0 / Math.max(1, counts[0]) / 2.3, 9);
    let idx = 0, svg = '';
    order.forEach(pi => { for (let s = 0; s < seats[pi]; s++) { const d = dots[idx++]; if (!d) break; svg += `<circle cx="${(cx + Math.cos(d.a) * d.r).toFixed(1)}" cy="${(cy - Math.sin(d.a) * d.r).toFixed(1)}" r="${dr.toFixed(1)}" fill="${cols[pi]}"/>`; } });
    svg += `<line x1="${cx}" x2="${cx}" y1="${cy - R - 6}" y2="${cy - r0 + 6}" stroke="#ffffff55" stroke-dasharray="2 3"/>`;
    return wrap(`<svg width="100%" viewBox="0 0 ${W} ${H}">${svg}<text x="${cx}" y="${cy - 4}" text-anchor="middle" style="font-size:20px;font-weight:700;fill:#e8eefb">${total}</text></svg>`);
  };

  /* Region map. fill(i) -> colour, label(i) -> string */
  UI.map = function (regions, fill, o) {
    o = o || {}; let p = '', l = '';
    regions.forEach((r, i) => {
      if (!r.poly || r.poly.length < 3) return;
      const pts = r.poly.map(q => q[0] + ',' + q[1]).join(' ');
      p += `<polygon data-i="${i}" points="${pts}" fill="${fill(i)}" stroke="#0a101c" stroke-width=".9" stroke-linejoin="round" style="cursor:pointer"/>`;
      if (o.label) l += `<text x="${r.site[0]}" y="${r.site[1] + 1.5}" text-anchor="middle" style="font-size:3.6px;fill:#fff;pointer-events:none;font-weight:600;paint-order:stroke;stroke:#000a;stroke-width:.5px">${SC.esc(o.label(i))}</text>`;
    });
    const el = wrap(`<svg viewBox="0 0 100 100" width="100%" style="max-height:340px">${p}${l}</svg>`);
    if (o.onTap) el.addEventListener('click', e => { const t = e.target.closest('polygon'); if (t) o.onTap(+t.dataset.i); });
    return el;
  };

  /* Procedural portrait */
  const SKIN = ['#f6d6bd', '#ecc0a0', '#d6a27c', '#b77f58', '#8d5b3d', '#5f3c28'], HAIR = ['#1b1511', '#4b3121', '#8a5a2c', '#c9a06a', '#9a9a9a', '#dcdcdc'];
  const SUIT = { treasury: '#3a5a8a', business: '#5a4a8a', welfare: '#8a4a6a', health: '#4a8a7a', education: '#4a7a9a', interior: '#7a3a3a', defence: '#4a5a4a', foreign: '#3a4a7a', transport: '#5a7a5a', environment: '#3a8a5a', culture: '#8a6a3a' };
  UI.portrait = function (m, size, frame) {
    size = size || 52; const sk = SKIN[m.skin % 6], hc = HAIR[m.hcol % 6], su = SUIT[m.dept] || '#445';
    const hairs = [
      `<path d="M20 27c0-9 5-15 12-15s12 6 12 15c-3-4-7-6-12-6s-9 2-12 6z" fill="${hc}"/>`,
      '',
      `<path d="M19 30c0-10 5-18 13-18s13 8 13 18v14c-2 0-4-2-4-6V27c-3-3-6-4-9-4s-6 1-9 4v11c0 4-2 6-4 6z" fill="${hc}"/>`,
      `<path d="M19 31c0-10 5-18 13-18s13 8 13 18c0 2-2 4-4 4V27c-3-3-6-4-9-4s-6 1-9 4v8c-2 0-4-2-4-4z" fill="${hc}"/>`,
      `<g fill="${hc}"><circle cx="22" cy="22" r="5"/><circle cx="29" cy="17" r="5.5"/><circle cx="36" cy="17" r="5.5"/><circle cx="42" cy="22" r="5"/></g>`,
      `<path d="M20 28c0-9 5-15 12-15s12 6 12 15c-1-2-3-4-5-5-5 2-12 2-17 2z" fill="${hc}"/>`,
      `<g fill="${hc}"><path d="M20 27c0-9 5-15 12-15s12 6 12 15c-3-4-7-6-12-6s-9 2-12 6z"/><circle cx="32" cy="10" r="4.5"/></g>`
    ];
    const gl = m.glasses ? '<g fill="none" stroke="#222" stroke-width="1.1"><rect x="23.5" y="26" width="7" height="5.2" rx="2"/><rect x="33.5" y="26" width="7" height="5.2" rx="2"/><path d="M30.5 28h3"/></g>' : '';
    const svg = `<svg width="${size}" height="${size}" viewBox="0 0 64 64"><rect width="64" height="64" fill="#1c2946"/><path d="M8 64c0-13 9-19 24-19s24 6 24 19z" fill="${su}"/><path d="M26 46l6 8 6-8z" fill="#f2f2f2"/><rect x="28.5" y="38" width="7" height="8" fill="${sk}"/><ellipse cx="32" cy="29" rx="11.2" ry="12.5" fill="${sk}"/>${m.gender === 'f' && m.hair % 7 === 1 ? hairs[3] : hairs[m.hair % 7]}<circle cx="27.5" cy="28.5" r="1.1" fill="#221"/><circle cx="36.5" cy="28.5" r="1.1" fill="#221"/>${gl}<path d="M28.5 35.5c2 1.5 5 1.5 7 0" stroke="#6b3a2a" stroke-width="1.2" fill="none" stroke-linecap="round"/></svg>`;
    return h('div', { class: 'portrait', style: { width: size + 'px', height: size + 'px', borderColor: frame || '' }, html: svg });
  };

  /* Ideology display: dots for each party on each axis */
  UI.ideoView = function (items) { // items: [{name,color,ideo}]
    return h('div', null, SC.AXES.map((ax, a) => h('div', { class: 'ideo' },
      h('div', { class: 'labels' }, h('span', null, ax.lo), h('b', { style: { color: 'var(--text)' } }, ax.n), h('span', null, ax.hi)),
      h('div', { class: 'track' }, items.map(it => h('span', { class: 'dot', title: it.name, style: { left: ((it.ideo[a] + 1) / 2 * 100) + '%', background: it.color } }))))));
  };

  UI.legendRow = items => h('div', { class: 'legend' }, items.map(i => h('span', null, h('i', { style: { background: i.c } }), i.n)));
})();
